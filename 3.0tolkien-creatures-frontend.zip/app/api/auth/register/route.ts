import { type NextRequest, NextResponse } from "next/server"

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8080"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    console.log("[v0] Register attempt:", { username: body.username, email: body.email })

    const response = await fetch(`${API_URL}/api/auth/register`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    })

    const data = await response.json()

    if (!response.ok) {
      console.log("[v0] Registration failed:", data)
      return NextResponse.json(data, { status: response.status })
    }

    console.log("[v0] Registration successful")
    return NextResponse.json(data, { status: 201 })
  } catch (error) {
    console.error("[v0] Registration error:", error)
    return NextResponse.json({ message: "Error al conectar con el servidor" }, { status: 500 })
  }
}
