package com.tolkien.pets.controller;

import com.tolkien.pets.dto.creature.CreateCreatureDto;
import com.tolkien.pets.dto.creature.UpdateCreatureDto;
import com.tolkien.pets.model.Creature;
import com.tolkien.pets.security.CustomPrincipal;
import com.tolkien.pets.service.CreatureService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/creatures")
public class CreatureController {

    private final CreatureService service;

    public CreatureController(CreatureService service) {
        this.service = service;
    }

    private CustomPrincipal getPrincipal(Authentication auth) {
        return (CustomPrincipal) auth.getPrincipal();
    }

    /* 🟢 Crear una nueva criatura */
    @PostMapping
    public ResponseEntity<?> createCreature(
            @RequestBody CreateCreatureDto creatureDto,
            @Parameter(hidden = true) Authentication auth
    ) {
        try {
            CustomPrincipal cp = getPrincipal(auth);
            Creature created = service.createCreature(creatureDto, cp.getUsername());
            return ResponseEntity.status(HttpStatus.CREATED).body(created);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Error de autenticación: " + e.getMessage());
        }
    }

    /* ⚔️ Entrenar una criatura */
    @PutMapping("/{id}/train")
    public ResponseEntity<?> trainCreature(
            @PathVariable Long id,
            @Parameter(hidden = true) Authentication auth
    ) {
        try {
            CustomPrincipal cp = getPrincipal(auth);
            Creature trained = service.trainCreature(id, cp.getUsername());
            return ResponseEntity.ok(trained);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error al entrenar criatura: " + e.getMessage());
        }
    }

    /* 💤 Descansar */
    @PutMapping("/{id}/rest")
    public ResponseEntity<?> restCreature(
            @PathVariable Long id,
            @Parameter(hidden = true) Authentication auth
    ) {
        try {
            CustomPrincipal cp = getPrincipal(auth);
            Creature rested = service.restCreature(id, cp.getUsername());
            return ResponseEntity.ok(rested);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error al descansar criatura: " + e.getMessage());
        }
    }
}
