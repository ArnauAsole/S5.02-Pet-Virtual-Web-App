package com.tolkien.pets.service.impl;

import com.tolkien.pets.dto.creature.CreateCreatureDto;
import com.tolkien.pets.dto.creature.UpdateCreatureDto;
import com.tolkien.pets.model.Creature;
import com.tolkien.pets.model.User;
import com.tolkien.pets.repo.CreatureRepo;
import com.tolkien.pets.repo.UserRepo;
import com.tolkien.pets.service.CreatureService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class CreatureServiceImpl implements CreatureService {

    private final CreatureRepo creatureRepo;
    private final UserRepo userRepo;

    public CreatureServiceImpl(CreatureRepo creatureRepo, UserRepo userRepo) {
        this.creatureRepo = creatureRepo;
        this.userRepo = userRepo;
    }

    @Override
    public List<Creature> getAllCreatures() {
        return creatureRepo.findAll();
    }

    @Override
    public Creature getCreatureById(Long id) {
        return creatureRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Creature not found"));
    }

    @Override
    public Creature createCreature(CreateCreatureDto dto, String username) {
        User owner = userRepo.findByEmail(username)
                .orElseThrow(() -> new IllegalArgumentException("Usuario no encontrado: " + username));

        Creature c = new Creature();
        c.setName(dto.getName());
        c.setRace(dto.getRace());
        c.setCharacterClass(dto.getCharacterClass()); // <-- ahora enum, sin conversiones
        c.setImageUrl(dto.getImageUrl());             // puede ser null y es OK

        // Valores base (ajústalos si ya los tienes en otro sitio)
        c.setLevel(1);
        c.setExperience(0);
        c.setHealth(100);
        c.setAttack(10);
        c.setDefense(10);
        c.setInCombat(false);

        c.setOwner(owner);

        return creatureRepo.save(c);
    }


    @Override
    public Creature updateCreature(Long id, UpdateCreatureDto dto, String username) {
        Creature creature = getCreatureById(id);

        if (dto.getName() != null) creature.setName(dto.getName());
        if (dto.getRace() != null) creature.setRace(dto.getRace());
        if (dto.getCharacterClass() != null) creature.setCharacterClass(dto.getCharacterClass());
        if (dto.getImageUrl() != null) creature.setImageUrl(dto.getImageUrl());
        if (dto.getHealth() > 0) creature.setHealth(dto.getHealth());
        if (dto.getAttack() > 0) creature.setAttack(dto.getAttack());
        if (dto.getDefense() > 0) creature.setDefense(dto.getDefense());

        return creatureRepo.save(creature);
    }

    @Override
    public void deleteCreature(Long id, String username) {
        Creature creature = getCreatureById(id);
        creatureRepo.delete(creature);
    }

    @Override
    public Creature trainCreature(Long id, String username) {
        Creature creature = getCreatureById(id);

        // Aumenta experiencia
        creature.setExperience(creature.getExperience() + 20);

        // Subida de nivel cada 100 XP
        if (creature.getExperience() >= 100) {
            creature.setExperience(0);
            levelUp(creature);
        }

        return creatureRepo.save(creature);
    }

    @Override
    public Creature restCreature(Long id, String username) {
        Creature creature = getCreatureById(id);

        int recovered = Math.min(creature.getHealth() + 20, 100);
        creature.setHealth(recovered);

        return creatureRepo.save(creature);
    }

    @Override
    public List<Creature> getCreaturesByOwnerId(Long ownerId) {
        return creatureRepo.findByOwnerId(ownerId);
    }

    private void levelUp(Creature creature) {
        creature.setLevel(creature.getLevel() + 1);
        creature.setHealth((int) Math.round(creature.getHealth() * 1.10));
        creature.setAttack((int) Math.round(creature.getAttack() * 1.05));
        creature.setDefense((int) Math.round(creature.getDefense() * 1.05));
    }
}
