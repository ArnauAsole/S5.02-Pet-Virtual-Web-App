package com.tolkien.pets.service;

import com.tolkien.pets.dto.creature.CreateCreatureDto;
import com.tolkien.pets.dto.creature.UpdateCreatureDto;
import com.tolkien.pets.model.Creature;
import java.util.List;

public interface CreatureService {
    List<Creature> getAllCreatures();
    Creature getCreatureById(Long id);
    Creature createCreature(CreateCreatureDto dto, String username);
    Creature updateCreature(Long id, UpdateCreatureDto dto, String username);
    void deleteCreature(Long id, String username);
    Creature trainCreature(Long id, String username);
    Creature restCreature(Long id, String username);
    List<Creature> getCreaturesByOwnerId(Long ownerId);
}
