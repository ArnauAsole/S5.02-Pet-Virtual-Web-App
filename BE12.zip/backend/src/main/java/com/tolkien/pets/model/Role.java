package com.tolkien.pets.model;

public enum Role {
    ROLE_USER,
    ROLE_ADMIN
}
