package com.tolkien.pets.exception;

public class ConflictException extends RuntimeException {
    public ConflictException(String message) { super(message); }
}
