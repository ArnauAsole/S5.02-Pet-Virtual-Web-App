import { type NextRequest, NextResponse } from "next/server"

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8080"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    console.log("[v0] Login attempt:", { username: body.username })

    const response = await fetch(`${API_URL}/api/auth/login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    })

    const data = await response.json()

    if (!response.ok) {
      console.log("[v0] Login failed:", data)
      return NextResponse.json(data, { status: response.status })
    }

    console.log("[v0] Login successful")
    return NextResponse.json(data, { status: 200 })
  } catch (error) {
    console.error("[v0] Login error:", error)
    return NextResponse.json({ message: "Error al conectar con el servidor" }, { status: 500 })
  }
}
