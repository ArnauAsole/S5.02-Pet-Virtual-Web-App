package com.tolkien.pets.dto.auth;

public record TokenDto(String token) {
}
