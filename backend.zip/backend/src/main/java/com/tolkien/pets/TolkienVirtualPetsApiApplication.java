package com.tolkien.pets;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TolkienVirtualPetsApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(TolkienVirtualPetsApiApplication.class, args);
    }

}
